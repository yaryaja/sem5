# Interactive Cell Program


## Introduction
This program is an interactive cell that provides a simple shell environment with a set of basic commands, including `echo`, `pwd`, `cd`, and `history`. It is designed to run in a terminal, providing a user-friendly interface to execute these commands.

## Features
- Interactive shell environment.
- Support for basic shell commands: `echo`, `pwd`, `cd`, and `history`.
- History tracking for previously executed commands.
- A Makefile for easy compilation.



## Usage

### Prerequisites
- C/C++ compiler (e.g., GCC)

### Building
To build the program, open your terminal, navigate to the program's directory, 
and run the following command: make && ./main


